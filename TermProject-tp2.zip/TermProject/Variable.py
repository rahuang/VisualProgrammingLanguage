import string
from Tkinter import *

class Variable(object):
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.width = 100
        self.height = 15
        self.nameVal = ["", ""]
        self.nameValSelected = None
        self.depth = 0
        self.selected = False
        v1 = StringVar()
        self.nameInput = Entry(width=10,textvariable=v1)
        v1.set(self.nameVal[0])
        v2 = StringVar()
        self.valueInput = Entry(width=13,textvariable=v2)
        v2.set(self.nameVal[1])

    def move(self, x, y):
        self.x, self.y = x, y

    def setText(self, text):
        self.printText = text

    def draw(self, canvas):
        outlineColor = "black"
        if(self.selected):
            outlineColor = "red"
        canvas.create_rectangle(self.x-self.width,self.y-self.height, self.x+self.width, self.y+self.height, fill="pink", outline=outlineColor)
        canvas.create_text(self.x-self.width+5, self.y-self.height+5, text="set\t         to ", anchor="nw", font="Arial 10 bold")

        outlineColor = "red" if self.nameValSelected == 0 else "black"
        canvas.create_window(self.x-self.width+30, self.y-self.height+5, window=self.nameInput, anchor="nw")
        #canvas.create_rectangle(self.x-self.width+30, self.y-self.height+5, self.x-self.width+90, self.y-self.height+25, outline=outlineColor)
        #canvas.create_text(self.x-self.width+30, self.y-self.height+5, text=self.nameVal[0], anchor="nw", font="Arial 10 bold")
        outlineColor = "red" if self.nameValSelected == 1 else "black"
        canvas.create_window(self.x-self.width+110, self.y-self.height+5, window=self.valueInput, anchor="nw")
        #canvas.create_rectangle(self.x-self.width+120, self.y-self.height+5, self.x-self.width+190, self.y-self.height+25, outline=outlineColor)
        #canvas.create_text(self.x-self.width+120, self.y-self.height+5, text=self.nameVal[1], anchor="nw", font="Arial 10 bold")

    def selectInput(self, x, y):
        if(self.x-self.width+30<=x<=self.x-self.width+90 and self.y-self.height+5<=y<=self.y-self.height+25):
            self.nameValSelected = 0
            return 0
        elif(self.x-self.width+120<=x<=self.x-self.width+190 and self.y-self.height+5<=y<=self.y-self.height+25):
            self.nameValSelected = 1
            return 1
        self.nameValSelected = None
        return None

    def inRange(self, x, y):
        if(self.x-self.width<=x<=self.x+self.width and self.y-self.height<=y<=self.y+self.height):
            return self
        else:
            return None

    def inRangeWithoutPop(self, x, y):
        if(self.x-self.width<=x<=self.x+self.width and self.y-self.height<=y<=self.y+self.height):
            return self
        else:
            return None

    def __str__(self):
        self.nameVal = [self.nameInput.get(), self.valueInput.get()]
        return str(self.nameVal[0]) + " = " + str(self.nameVal[1])