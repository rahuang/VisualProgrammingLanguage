class Tab(object):
    def __init__(self, x, y, name):
        self.width = 30
        self.height = 10
        self.closeSize = 10
        self.x = x
        self.y = y
        self.name = name
        self.selected = False

    def inRange(self, x, y):
        if(self.x-self.width<=x<=self.x+self.width and self.y-self.height<=y<=self.y+self.height):
            return True
        return False

    def inRangeClose(self, x, y):
        if(self.x+self.width<=x<=self.x+self.width+self.closeSize and self.y-self.height<=y<=self.y+self.height):
            return True
        return False

    def setXY(self, x, y):
        self.x = x
        self.y = y

    def setName(self, name):
        self.name = name

    def draw(self, canvas):
        color = "green"
        if(self.selected):
            color = "darkgreen"
        canvas.create_rectangle(self.x-self.width,self.y-self.height,self.x+self.width, self.y+self.height, fill=color)
        canvas.create_text(self.x-self.width+5,self.y-self.height, text=self.name, anchor="nw")
        canvas.create_rectangle(self.x+self.width, self.y-self.height, self.x+self.width+self.closeSize, self.y+self.height, fill="red")

