from Tkinter import *


class dashboard(object):
    def __init__(self, canvas):
        self.labels = []
        self.convertedCode = ""
        
        self.code = ""

    def displayCode(self, code):
        self.code = code
        

    def inRange(self, x, y):
        for i in xrange(len(self.labels)):
            obj = self.labels[i].inRange(x, y)
            if(obj != None):
                return obj
        return None

    def addLabel(self, obj):
        self.labels.append(obj)

    def draw(self, canvas):
        canvas.create_line(700, 350, 1400, 350)
        canvas.create_text(800, 400, text=self.code, anchor="nw")
        for i in xrange(len(self.labels)):
            self.labels[i].draw(canvas)

    def setConvertCode(self, code):
        self.convertedCode = code
