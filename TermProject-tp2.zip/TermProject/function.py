from Tkinter import *
from Print import Print
from IfStatement import IfStatement
from ForLoop import ForLoop
from Variable import Variable
from WhileLoop import WhileLoop


class function(object):
    def __init__(self, name="function", param=[]):
        self.param = param
        self.do = []
        self.funcName = name
        self.depth = 1

        self.nameInput = StringVar()
        self.functionNameInput = Entry(width=10, textvariable=self.nameInput)
        self.nameInput.set(self.funcName)

        self.paramInput = StringVar()
        self.functionParamInput = Entry(width=10, textvariable=self.paramInput)
        self.paramInput.set(str(self.param)[1:-1])


    def setName(self):
        self.funcName = self.functionNameInput.get()

    def setParams(self):
        self.param = self.functionParamInput.get().split(",")

    def addDo(self, obj):
        self.do.append(obj)
        self.do.sort(key=lambda obj: obj.y)
        #print self.do

    def processObj(self):
        for i in xrange(len(self.do)):
            try:
                self.do[i].processObj()
            except:
                pass

    def draw(self, canvas):
        canvas.create_text(10, 10, text="Enter function name: ", anchor="w")
        canvas.create_window(130, 10, window=self.functionNameInput, anchor="w")
        canvas.create_text(200, 10, text="Enter function params: ", anchor="w")
        canvas.create_window(330, 10, window=self.functionParamInput, anchor="w")
        if(self.do != []):
            for i in xrange(len(self.do)):
                statement = self.do[i]
                statement.draw(canvas)

    def inRange(self, x, y):
        for i in xrange(len(self.do)-1, -1, -1):
            tmp = self.do[i].inRange(x, y)
            if(tmp != None):
                if(self.do[i] is tmp and isinstance(self.do[i], IfStatement)):
                    print "1"
                    self.do.pop(i)
                elif(self.do[i] is tmp and isinstance(self.do[i], ForLoop)):
                    print "2"
                    self.do.pop(i)
                elif(self.do[i] is tmp and isinstance(self.do[i], WhileLoop)):
                    print "3"
                    self.do.pop(i)
                elif(isinstance(self.do[i], Print)):
                    print "4"
                    self.do.pop(i)
                elif(isinstance(self.do[i], Variable)):
                    print "5"
                    self.do.pop(i)
                return tmp
        return None

    def inRangeWithoutPop(self, x, y):
        for i in xrange(len(self.do)-1, -1, -1):
            tmp = self.do[i].inRangeWithoutPop(x, y)
            if(tmp != None):
                return tmp
        return None

    def __str__(self):
        string = "def "
        params = ""
        for i in xrange(len(self.param)):
            params += self.param[i].strip() + ", " if i != len(self.param)-1 else self.param[i].strip()


        string += self.funcName + "(" + params + "):\n"
        for i in xrange(len(self.do)):
            self.do[i].depth = self.depth + 1
            string += self.depth*"    " +str(self.do[i]) + "\n"
        return string
