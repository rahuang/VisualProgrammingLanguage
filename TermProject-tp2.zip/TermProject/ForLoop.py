import string
from Nested import Nested
from Tkinter import *

class ForLoop(Nested):
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.width = 120
        self.height = 25
        self.range = ["", "", ""]
        self.selectedRange = None
        self.do = []
        self.depth = 0
        self.selected = False
        v1 = StringVar()
        self.varInput = Entry(width=4,textvariable=v1)
        v1.set(self.range[0])
        v2 = StringVar()
        self.startInput = Entry(width=4,textvariable=v2)
        v2.set(self.range[1])
        v3 = StringVar()
        self.endInput = Entry(width=4,textvariable=v3)
        v3.set(self.range[2])
            
    def draw(self, canvas):
        outlineColor = "black"
        if(self.selected):
            outlineColor = "red"
        #text = "loop from: " + self.range[0] + " to: " + self.range[1] + " (inclusive)"
        text = "loop variable:        from:         to: "
        canvas.create_rectangle(self.x-self.width,self.y-self.height, self.x+self.width, self.y+self.height, fill="yellow", outline=outlineColor)
        canvas.create_text(self.x-self.width+5, self.y-self.height+5, text=text, anchor="nw", font="Arial 10 bold")

        canvas.create_window(self.x-self.width+95, self.y-self.height+1, window=self.varInput, anchor="nw")
        canvas.create_window(self.x-self.width+160, self.y-self.height+1, window=self.startInput, anchor="nw")
        canvas.create_window(self.x-self.width+210, self.y-self.height+1, window=self.endInput, anchor="nw")

        canvas.create_line(self.x-self.width, self.y-self.height+20, self.x+self.width, self.y-self.height+20, width="1")
        canvas.create_text(self.x-self.width+5, self.y-self.height+25, text="do", anchor="nw", font="Arial 10 bold")
        for i in xrange(len(self.do)):
            self.do[i].draw(canvas)

    def selectInput(self, x, y):
        if(self.x-self.width+95<=x<=self.x-self.width+124 and self.y-self.height+1<=y<=self.y-self.height+19):
            self.selectedRange = 0
            return 0
        elif(self.x-self.width+160<=x<=self.x-self.width+190 and self.y-self.height+1<=y<=self.y-self.height+19):
            self.selectedRange = 1
            return 1
        elif(self.x-self.width+210<=x<=self.x-self.width+240 and self.y-self.height+1<=y<=self.y-self.height+19):
            self.selectedRange = 2
            return 2
        self.selectedRange = None
        return None


    def __str__(self):
        self.range = [self.varInput.get(), self.startInput.get(), self.endInput.get()]
        s = "for " + str(self.range[0]) + " in xrange(" + str(self.range[1]) + ", " 
        s += str(int(self.range[2]) + 1) + "):\n" if(self.range[2] != "") else self.range[2] + "):\n"
        for i in xrange(len(self.do)):
            self.do[i].depth = self.depth + 1
            s += self.depth*"    " +str(self.do[i])
            s += "\n" if i != len(self.do) - 1 else ""
        return s