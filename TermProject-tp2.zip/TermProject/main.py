from __future__ import with_statement # for Python 2.5 and 2.6
from Tkinter import *
from eventBasedAnimationClass import EventBasedAnimationClass
from function import function
from Print import Print
from IfStatement import IfStatement
from dashboard import dashboard
from ForLoop import ForLoop
from Nested import Nested
from Variable import Variable
from WhileLoop import WhileLoop
from Tab import Tab
import random
import contextlib # for urllib.urlopen()
import urllib
import os
import tkMessageBox
import tkSimpleDialog

class runVisualProgrammer(EventBasedAnimationClass):

    def leftMousePressed(self, event):
        x, y = event.x, event.y
        
        if(self.inRangeTabs(x, y)):
            return

        obj = self.dashboard.inRange(x, y)
        if(isinstance(obj, Print)):
            self.tmpDrag = Print(x, y)
            self.Draggable = True
        elif(isinstance(obj, IfStatement)):
            self.tmpDrag = IfStatement(x, y)
            self.Draggable = True
        elif(isinstance(obj, ForLoop)):
            self.tmpDrag = ForLoop(x, y)
            self.Draggable = True
        elif(isinstance(obj, WhileLoop)):
            self.tmpDrag = WhileLoop(x, y)
            self.Draggable = True
        elif(isinstance(obj, Variable)):
            self.tmpDrag = Variable(x, y)
            self.Draggable = True
        else:
            if(self.highLighted != None):
                self.highLighted.selected = False
            self.tmpDrag = self.function[self.functionNum].inRange(x, y)
            if(self.tmpDrag != None):
                self.highLighted = self.tmpDrag
                self.highLighted.selected = True
                self.Draggable = True

    def leftMouseMoved(self, event):
        if(self.Draggable):
            self.tmpDrag.move(event.x, event.y)


    def leftMouseReleased(self, event):
        x, y = event.x, event.y
        if(self.Draggable):
            if(x <= self.cx):
                tmp = self.function[self.functionNum].inRangeWithoutPop(x, y) 
                if(isinstance(tmp, Nested)):
                    #self.function.addDo(tmp)
                    tmp.addDo(self.tmpDrag)
                else:
                    #if(tmp != None): self.function.addDo(tmp)
                    self.function[self.functionNum].addDo(self.tmpDrag)
            self.tmpDrag = None
            self.Draggable = False
            self.function[self.functionNum].processObj()

    def inRangeTabs(self, x, y):
        for i in xrange(len(self.tabButtons)):
            if(self.tabButtons[i].inRange(x, y)):
                self.functionNum = i
                return True
                
        for i in xrange(len(self.tabButtons)):
            if(self.tabButtons[i].inRangeClose(x, y)):
                self.function.pop(i)
                self.tabButtons.pop(i)
                self.functionNum = self.functionNum if i < len(self.tabButtons) - 1 else self.functionNum - 1
                self.processTabs()
                return True
        return False

    def processTabs(self):
        x = 40
        for i in xrange(len(self.tabButtons)):
            self.tabButtons[i].x = x
            x += 80


    def onKeyPressed(self, event):
        pass

    def convertToPython(self):
        self.function[self.functionNum].setName()
        self.function[self.functionNum].setParams()
        self.dashboard.displayCode(str(self.function[self.functionNum]))
        for i in xrange(len(self.tabButtons)):
            self.tabButtons[i].setName(self.function[i].funcName)
        
            
    def drawDashboard(self):
        canvas = self.canvas
        canvas.create_line(self.cx, 0, self.cx, self.height)
        canvas.create_window(1000, 300, window=self.convertButton, anchor="w")
        self.dashboard.draw(canvas)


    def drawFunction(self):
        self.function[self.functionNum].draw(self.canvas)

    def drawDrag(self):
        if(self.tmpDrag != None):
            self.tmpDrag.draw(self.canvas)

    def drawProgram(self):
        canvas = self.canvas
        canvas.create_window(100, 30, window=self.newFunction, anchor="w")
        #canvas.create_window(100, 60, window=self.switchFunction, anchor="w")
        #print self.switchFunction.getWidth()
        for i in xrange(len(self.tabButtons)):
            self.tabButtons[i].draw(canvas)
        '''
        x, y = 0, 60
        for i in xrange(len(self.tabButtons)):
            canvas.create_window(x, y, window=self.tabButtons[i], anchor="w")
            x += 60
        #self.tab.draw(canvas)'''

    def redrawAll(self):
        canvas = self.canvas
        canvas.delete(ALL)
        self.drawDashboard()
        self.drawProgram()
        self.drawFunction()
        self.drawDrag()

    def switchFunctions(self, pos):
        self.functionNum = pos

    def newFunction(self):
        self.function.append(function())
        self.switchFunctions(len(self.function) - 1)
        x, y = (self.tabButtons[-1].x + 80, self.tabButtons[-1].y) if len(self.tabButtons) != 0 else (40, 60)
        self.tabButtons.append(Tab(x, y, self.function[-1].funcName))


    def initDashBoard(self):
        dashPrint = Print(self.width - 7*self.size, 120)
        dashIfStatement = IfStatement(self.width - 7*self.size, 180)
        dashForLoop = ForLoop(self.width - 7*self.size, 240)
        dashVariable = Variable(self.width - 12*self.size + 20, 120)
        dashWhileLoop = WhileLoop(self.width - 12*self.size + 20, 180)
        self.dashboard = dashboard(self.canvas)
        self.dashboard.addLabel(dashPrint)
        self.dashboard.addLabel(dashIfStatement)
        self.dashboard.addLabel(dashForLoop)
        self.dashboard.addLabel(dashVariable)
        self.dashboard.addLabel(dashWhileLoop)

    def initAnimation(self):
        self.x = -1
        self.y = -1
        self.size = 50
        self.cx, self.cy = self.width/2, self.height/2
        self.functionNum = 0
        self.function = [function()]
        self.Draggable = False
        self.tmpDrag = None
        self.selected = None
        self.initDashBoard()
        self.highLighted = None
        self.convertButton = Button(self.canvas, text="Convert to Python", command=self.convertToPython)

        self.newFunction = Button(self.canvas, text="New Function", command=self.newFunction)
        #self.tabButtons = [Button(self.canvas, text="function", command=(lambda:self.switchFunctions(0)))]
        self.tabButtons = [Tab(40, 60, self.function[0].funcName)]
        
rvp = runVisualProgrammer(1400, 700)
rvp.run()
