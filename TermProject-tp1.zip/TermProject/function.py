from Print import Print
from IfStatement import IfStatement

class function(object):
    def __init__(self, name="function", param=dict()):
        self.param = param
        self.do = []
        self.funcName = name
        self.depth = 1

    def addDo(self, obj):
        self.do.append(obj)
        self.do.sort(key=lambda obj: obj.y)
        #print self.do

    def processObj(self):
        for i in xrange(len(self.do)):
            try:
                self.do[i].processObj()
            except:
                pass

    def inRange(self, x, y):
        for i in xrange(len(self.do)-1, -1, -1):
            tmp = self.do[i].inRange(x, y)
            if(tmp != None):
                '''
                if(isinstance(tmp, Print)):
                    self.do.pop(i)
                    return tmp
                elif(isinstance(tmp, IfStatement)):
                    if(self.do[i] is tmp):
                        self.do.pop(i)
                    return tmp
                    '''
                if(self.do[i] is tmp and isinstance(self.do[i], IfStatement)):
                    self.do.pop(i)
                elif(isinstance(self.do[i], Print)):
                    self.do.pop(i)
                return tmp

        return None

    def inRangeWithoutPop(self, x, y):
        for i in xrange(len(self.do)-1, -1, -1):
            tmp = self.do[i].inRangeWithoutPop(x, y)
            if(tmp != None):
                return tmp
        return None

    def __str__(self):
        string = "def "
        string += self.funcName + "():\n"
        for i in xrange(len(self.do)):
            self.do[i].depth = self.depth + 1
            string += self.depth*"    " +str(self.do[i]) + "\n"
        return string
