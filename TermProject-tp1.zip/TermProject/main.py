from __future__ import with_statement # for Python 2.5 and 2.6
from Tkinter import *
from eventBasedAnimationClass import EventBasedAnimationClass
from function import function
from Print import Print
from IfStatement import IfStatement
from dashboard import dashboard
import random
import contextlib # for urllib.urlopen()
import urllib
import os
import tkMessageBox
import tkSimpleDialog

class MyPrintDialog(tkSimpleDialog.Dialog):
    def body(self, master):
        self.val = ""
        Label(master, text="Enter Text to Print:").grid(row=0)
        self.e1 = Entry(master)
        self.e1.grid(row=0, column=1)
        self.e1.insert(0, self.parent.tmpText)
        return self.e1
    def apply(self):
        first = self.e1.get()
        self.val = first

class MyIfStatementDialog(tkSimpleDialog.Dialog):
    def body(self, master):
        self.val = ""
        Label(master, text="Enter the condition: ").grid(row=0)
        self.e1 = Entry(master)
        self.e1.grid(row=0, column=1)
        self.e1.insert(0, self.parent.tmpConditon)
        return self.e1
    def apply(self):
        first = self.e1.get()
        self.val = first

class runVisualProgrammer(EventBasedAnimationClass):

    def onMousePressed(self, event):
        x, y = event.x, event.y
        self.selected = self.function.inRangeWithoutPop(x, y)
        #self.leftMouseReleased(event)
        if(self.selected != None):
            self.Draggable = True
            if(isinstance(self.selected, Print)):
                self.canvas.tmpText = self.selected.printText
                md = MyPrintDialog(self.canvas, "Print Dialog")
                self.canvas.tmpText = ""
                self.selected.setText(md.val)
            elif(isinstance(self.selected, IfStatement)):
                self.canvas.tmpConditon = self.selected.condition
                md = MyIfStatementDialog(self.canvas, "If Stament")
                self.selected.condition = md.val
        

    def leftMousePressed(self, event):
        x, y = event.x, event.y
        obj = self.dashboard.inRange(x, y)
        if(isinstance(obj, Print)):
            self.tmpDrag = Print(x, y)
            self.Draggable = True
        elif(isinstance(obj, IfStatement)):
            self.tmpDrag = IfStatement(x, y)
            self.Draggable = True
        else:
            if(self.highLighted != None):
                self.highLighted.selected = False
            self.tmpDrag = self.function.inRange(x, y)
            if(self.tmpDrag != None):
                self.highLighted = self.tmpDrag
                self.highLighted.selected = True
                self.Draggable = True



    def leftMouseMoved(self, event):
        if(self.Draggable):
            self.tmpDrag.move(event.x, event.y)


    def leftMouseReleased(self, event):
        x, y = event.x, event.y
        if(self.Draggable):
            if(x <= self.cx):
                tmp = self.function.inRangeWithoutPop(x, y) 
                if(isinstance(tmp, IfStatement)):
                    #self.function.addDo(tmp)
                    tmp.addDo(self.tmpDrag)
                else:
                    #if(tmp != None): self.function.addDo(tmp)
                    self.function.addDo(self.tmpDrag)
            self.tmpDrag = None
            self.Draggable = False
            self.function.processObj()

    def onKeyPressed(self, event):
        if(event.char == "r"):  
            print self.function
            
    def drawDashboard(self):
        canvas = self.canvas
        #self.dashPrint.draw(canvas)
        #self.dashIfStatement.draw(canvas)
        canvas.create_line(self.cx, 0, self.cx, self.height)
        self.dashboard.draw(canvas)


    def drawFunction(self):
        canvas = self.canvas
        if(self.function.do != []):
            for i in xrange(len(self.function.do)):
                statement = self.function.do[i]
                statement.draw(canvas)

    def drawDrag(self):
        if(self.tmpDrag != None):
            self.tmpDrag.draw(self.canvas)

    def redrawAll(self):
        canvas = self.canvas
        canvas.delete(ALL)
        self.drawDashboard()
        self.drawFunction()
        self.drawDrag()

    def initDashBoard(self):
        dashPrint = Print(self.width - 7*self.size, 120)
        dashIfStatement = IfStatement(self.width - 7*self.size, 180)
        self.dashboard = dashboard()
        self.dashboard.addLabel(dashPrint)
        self.dashboard.addLabel(dashIfStatement)

    def initAnimation(self):
        self.x = -1
        self.y = -1
        self.size = 50
        self.cx, self.cy = self.width/2, self.height/2
        self.function = function()
        self.Draggable = False
        self.tmpDrag = None
        self.selected = None
        self.initDashBoard()
        self.highLighted = None

        
rvp = runVisualProgrammer(1400, 700)
rvp.run()
