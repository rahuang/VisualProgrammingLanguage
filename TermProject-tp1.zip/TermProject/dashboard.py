class dashboard(object):
    def __init__(self):
        self.labels = []
        self.convertedCode = ""

    def inRange(self, x, y):
        for i in xrange(len(self.labels)):
            obj = self.labels[i].inRange(x, y)
            if(obj != None):
                return obj
        return None

    def addLabel(self, obj):
        self.labels.append(obj)

    def draw(self, canvas):
        for i in xrange(len(self.labels)):
            self.labels[i].draw(canvas)

    def setConvertCode(self, code):
        self.convertedCode = code
